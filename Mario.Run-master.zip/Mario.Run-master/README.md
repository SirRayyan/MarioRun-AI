# Mario.Run
Mario running game based on P5.js

Live Demo: https://linuk.github.io/Mario.Run/index.html
